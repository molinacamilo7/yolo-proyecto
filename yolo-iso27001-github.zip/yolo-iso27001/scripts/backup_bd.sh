#!/usr/bin/env bash
# ============================================================
# backup_bd.sh
# Backup cifrado de inventario.db (Control ISO 27001: A.8.13)
# Uso: ./scripts/backup_bd.sh
# Programar con cron: 0 2 * * * /ruta/proyecto/scripts/backup_bd.sh
# ============================================================

set -e

DB_PATH="inventario.db"
BACKUP_DIR="./backups"
FECHA=$(date +"%Y%m%d_%H%M%S")
BACKUP_FILE="$BACKUP_DIR/inventario_$FECHA.db"
BACKUP_CIFRADO="$BACKUP_FILE.enc"

# ── Verificar que la BD existe ──────────────────────────────
if [ ! -f "$DB_PATH" ]; then
    echo "[ERROR] No se encontró $DB_PATH"
    exit 1
fi

# ── Crear carpeta de backups si no existe ───────────────────
mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"

# ── Hacer backup con punto de consistencia SQLite ───────────
echo "[1/3] Creando backup de $DB_PATH..."
sqlite3 "$DB_PATH" ".backup '$BACKUP_FILE'"
echo "      → $BACKUP_FILE"

# ── Cifrar el backup con AES-256 (usando OpenSSL) ──────────
echo "[2/3] Cifrando backup..."
echo ""
echo "  Ingresa una passphrase para el backup (guárdala en lugar seguro):"
openssl enc -aes-256-cbc -pbkdf2 -iter 100000 \
    -in "$BACKUP_FILE" \
    -out "$BACKUP_CIFRADO"

# Eliminar el backup sin cifrar
rm -f "$BACKUP_FILE"
echo "      → $BACKUP_CIFRADO (backup sin cifrar eliminado)"

# ── Verificar integridad del backup ─────────────────────────
echo "[3/3] Verificando hash SHA-256 del backup cifrado..."
HASH=$(sha256sum "$BACKUP_CIFRADO" | awk '{print $1}')
echo "      → SHA-256: $HASH"
echo "$HASH  $BACKUP_CIFRADO" > "$BACKUP_CIFRADO.sha256"

# ── Resumen ─────────────────────────────────────────────────
echo ""
echo "==========================================="
echo "  BACKUP COMPLETADO — ISO 27001 A.8.13"
echo "==========================================="
echo "  Archivo: $BACKUP_CIFRADO"
echo "  Hash:    $HASH"
echo "  Fecha:   $FECHA"
echo ""
echo "  Para restaurar:"
echo "  openssl enc -d -aes-256-cbc -pbkdf2 -iter 100000 \\"
echo "      -in $BACKUP_CIFRADO -out inventario_restaurado.db"
echo ""

# ── Limpiar backups antiguos (retener últimos 7) ────────────
echo "  Limpiando backups antiguos (se retienen los 7 más recientes)..."
ls -t "$BACKUP_DIR"/*.enc 2>/dev/null | tail -n +8 | while read f; do
    rm -f "$f" "${f}.sha256"
    echo "  Eliminado: $f"
done

echo "  ✓ Listo"
