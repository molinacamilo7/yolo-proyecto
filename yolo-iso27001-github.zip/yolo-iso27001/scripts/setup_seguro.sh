#!/usr/bin/env bash
# ============================================================
# setup_seguro.sh
# Configura el entorno de seguridad del proyecto ISO 27001
# Ejecutar UNA VEZ después de clonar el repositorio
# ============================================================

set -e

echo ""
echo "=========================================="
echo "  SETUP SEGURO — ISO 27001"
echo "=========================================="

# ── 1. Permisos restrictivos en archivos sensibles ─────────
echo ""
echo "[1/4] Configurando permisos de archivos sensibles..."

# Si existen, restringir acceso
for f in clave_privada.pem inventario.db; do
    if [ -f "$f" ]; then
        chmod 600 "$f"
        echo "  ✓ chmod 600 $f"
    fi
done

# La clave pública puede ser de solo lectura por todos
if [ -f "clave_publica.pem" ]; then
    chmod 644 "clave_publica.pem"
    echo "  ✓ chmod 644 clave_publica.pem"
fi

# Carpeta imagenes: solo el dueño puede leer/escribir
if [ -d "imagenes" ]; then
    chmod 700 "imagenes"
    echo "  ✓ chmod 700 imagenes/"
fi

# ── 2. Pre-commit hook: bloquea subida de archivos sensibles ─
echo ""
echo "[2/4] Instalando pre-commit hook anti-filtración..."

HOOK_FILE=".git/hooks/pre-commit"

cat > "$HOOK_FILE" << 'HOOK'
#!/usr/bin/env bash
# Pre-commit hook: bloquea archivos sensibles antes de cada commit

ARCHIVOS_PROHIBIDOS=("clave_privada.pem" "inventario.db" "*.pt" "*.db")

ERROR=0

# Verificar archivos en staging area
for patron in "${ARCHIVOS_PROHIBIDOS[@]}"; do
    archivos=$(git diff --cached --name-only | grep -E "${patron/\*/.*}" || true)
    if [ -n "$archivos" ]; then
        echo ""
        echo "🚨 BLOQUEADO POR PRE-COMMIT HOOK (ISO 27001 - Control A.8.12)"
        echo "   Archivo sensible detectado en el commit:"
        echo "   → $archivos"
        echo ""
        echo "   Para continuar, quita el archivo del staging:"
        echo "   git reset HEAD $archivos"
        echo ""
        ERROR=1
    fi
done

# Buscar claves PEM en cualquier archivo de texto en staging
if git diff --cached --name-only | xargs grep -l "BEGIN.*PRIVATE KEY" 2>/dev/null; then
    echo ""
    echo "🚨 BLOQUEADO: Se detectó contenido de clave privada en un archivo staged"
    echo "   Revisa los archivos que contienen '-----BEGIN PRIVATE KEY-----'"
    echo ""
    ERROR=1
fi

if [ $ERROR -eq 1 ]; then
    exit 1
fi

echo "✅ Pre-commit: sin archivos sensibles detectados"
exit 0
HOOK

chmod +x "$HOOK_FILE"
echo "  ✓ Hook instalado en .git/hooks/pre-commit"

# ── 3. Verificar .gitignore ──────────────────────────────────
echo ""
echo "[3/4] Verificando .gitignore..."

ENTRADAS_REQUERIDAS=(
    "clave_privada.pem"
    "inventario.db"
    "*.pt"
    "__pycache__/"
    "runs/"
)

for entrada in "${ENTRADAS_REQUERIDAS[@]}"; do
    if grep -qF "$entrada" .gitignore 2>/dev/null; then
        echo "  ✓ $entrada ya en .gitignore"
    else
        echo "$entrada" >> .gitignore
        echo "  + Agregado: $entrada"
    fi
done

# ── 4. Verificar que no hay claves en el historial de Git ───
echo ""
echo "[4/4] Verificando historial de Git por fugas de claves..."

if git log --all --full-history -- "clave_privada.pem" 2>/dev/null | grep -q "commit"; then
    echo ""
    echo "  ⚠️  ADVERTENCIA: clave_privada.pem aparece en el historial de Git"
    echo "     Debes rotar las claves y limpiar el historial con:"
    echo "     git filter-repo --invert-paths --path clave_privada.pem"
    echo ""
else
    echo "  ✓ No se encontraron claves privadas en el historial"
fi

# ── Resumen ──────────────────────────────────────────────────
echo ""
echo "=========================================="
echo "  SETUP COMPLETADO"
echo "=========================================="
echo ""
echo "  Próximos pasos:"
echo "  1. pip install -r requirements.txt"
echo "  2. Colocar imágenes/videos en ./imagenes/"
echo "  3. python sistema_inventario.py"
echo ""
echo "  ⚠️  La clave privada RSA NO tiene passphrase."
echo "     Para protegerla en producción, edita generar_claves_rsa()"
echo "     y usa: encryption_algorithm=serialization.BestAvailableEncryption(b'tu-passphrase')"
echo ""
