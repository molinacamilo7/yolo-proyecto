# Esta carpeta contiene las imágenes y videos capturados en campo.
# Los archivos aquí son ignorados por Git (.gitignore) por contener
# información sensible de infraestructura de telecomunicaciones.
# 
# Formatos soportados:
# - Imágenes: .jpg .jpeg .png .bmp .webp
# - Videos:   .mp4 .avi .mov .mkv .wmv

